var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
import fetch from 'node-fetch';
import { FormData } from "formdata-node";
import { FormDataEncoder } from 'form-data-encoder';
import { Readable } from 'stream';
import * as functions from '@google-cloud/functions-framework';
function generateGreenMoParameters(area) {
    const pos1 = `lon1=${area.pos1.lon}&lat1=${area.pos1.lat}`;
    const pos2 = `lon2=${area.pos2.lon}&lat2=${area.pos2.lat}`;
    return `${pos1}&${pos2}`;
}
function executeGreenMoRequest(area) {
    return __awaiter(this, void 0, void 0, function* () {
        const protocol = "https";
        const url = "greenmobility.frontend.fleetbird.eu";
        const endpoint = "api/prod/v1.06/map/cars";
        const params = generateGreenMoParameters(area);
        const fqdn = `${protocol}://${url}/${endpoint}/?${params}`;
        const response = yield fetch(fqdn);
        const expectedStatusCode = 200;
        if (response.status != expectedStatusCode) {
            yield exceptionPushoverRequest("Greenmo query failed");
            throw Error(`Invalid response code. Got ${response.status}, expected ${expectedStatusCode}`);
        }
        const result = (yield response.json());
        return result.filter(function (car, _) {
            return car.fuelLevel < 30;
        });
    });
}
function generateMapsParameters(positions) {
    var _a;
    const centerPos = {
        lat: 55.787867,
        lon: 12.521667
    };
    const center = `center=${centerPos.lat},${centerPos.lon}`;
    const size = "size=500x400";
    const key = `key=${(_a = process.env.GOOGLE_MAPS_API_TOKEN) !== null && _a !== void 0 ? _a : ''}`;
    const zoom = "zoom=14";
    const maptype = "maptype=satellite";
    const markers = positions.map((pos) => {
        return `markers=color:green%7Clabel:G%7C${pos.lat},${pos.lon}`;
    }).join("&");
    return `${center}&${size}&${key}&${zoom}&${maptype}&${markers}`;
}
function executeMapsRequest(positions) {
    return __awaiter(this, void 0, void 0, function* () {
        const protocol = "https";
        const url = "maps.googleapis.com";
        const endpoint = "maps/api/staticmap";
        const params = generateMapsParameters(positions);
        const fqdn = `${protocol}://${url}/${endpoint}?${params}`;
        const response = yield fetch(fqdn);
        const expectedStatusCode = 200;
        if (response.status != expectedStatusCode) {
            yield exceptionPushoverRequest("Maps query failed");
            throw Error(`Invalid response code. Got ${response.status}, expected ${expectedStatusCode}`);
        }
        return response.blob();
    });
}
function generatePushoverBody(msg, img) {
    var _a, _b;
    let formdata = new FormData();
    formdata.append("token", (_a = process.env.PUSHOVER_API_TOKEN) !== null && _a !== void 0 ? _a : "");
    formdata.append("user", (_b = process.env.PUSHOVER_API_USER) !== null && _b !== void 0 ? _b : "");
    formdata.append("message", msg);
    if (img) {
        formdata.append("attachment", img, "image.png");
    }
    return new FormDataEncoder(formdata);
}
function executePushoverRequest(img) {
    return __awaiter(this, void 0, void 0, function* () {
        const protocol = "https";
        const url = "api.pushover.net";
        const endpoint = "1/messages.json";
        const encoder = generatePushoverBody("Found some cars for charging.", img);
        const fqdn = `${protocol}://${url}/${endpoint}`;
        let requestOptions = {
            method: 'POST',
            headers: encoder.headers,
            body: Readable.from(encoder)
        };
        const response = yield fetch(fqdn, requestOptions);
        const expectedStatusCode = 200;
        if (response.status != expectedStatusCode) {
            yield exceptionPushoverRequest("Pushover notification failed");
            throw Error(`Invalid response code. Got ${response.status}, expected ${expectedStatusCode}`);
        }
    });
}
function exceptionPushoverRequest(msg) {
    return __awaiter(this, void 0, void 0, function* () {
        const protocol = "https";
        const url = "api.pushover.net";
        const endpoint = "1/messages.json";
        const encoder = generatePushoverBody(msg);
        const fqdn = `${protocol}://${url}/${endpoint}`;
        let requestOptions = {
            method: 'POST',
            headers: encoder.headers,
            body: Readable.from(encoder)
        };
        yield fetch(fqdn, requestOptions);
    });
}
function getPositions() {
    let positions = new Map();
    positions.set("DTU", {
        pos1: {
            lat: 55.794430,
            lon: 12.511368
        },
        pos2: {
            lat: 55.779566,
            lon: 12.527933
        }
    });
    return positions;
}
functions.http('GreenMoNotifier', (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    const location = "DTU"; // TODO: get it from cloudEvent, Access the CloudEvent data payload via cloudEvent.data
    const positions = getPositions();
    const carPossitions = yield executeGreenMoRequest(positions.get(location));
    if (carPossitions.length) {
        const img = yield executeMapsRequest(carPossitions);
        yield executePushoverRequest(img);
    }
    res.send('Success');
}));
